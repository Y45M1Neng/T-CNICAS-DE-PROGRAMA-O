#ifndef SISTEMA_INTERESTELAR_H_INCLUDED
#define SISTEMA_INTERESTELAR_H_INCLUDED

#include <string>
using namespace std;

struct CorpoCeleste{

    string nome;
    double raioPlaneta;
    double massa;

};
//Crie uma classe chamada Sistema_Interestelar que deverá conter dois atributos do tipo CorpoCeleste, um atributo para armazenar a distância entre os dois Corpos Celestes do tipo double, um atributo para armazenar o nome e um atributo constante do tipo const double para armazenar a constante gravitacional universal (6.67e-11 = 6.67*10-11).
class Sistema_Interestelar{

private:

    CorpoCeleste corpo_1;
    CorpoCeleste corpo_2;
    double distancia;
    const double constante_gravitacional = 6.67e-11;
public:
    void DadosPlanetas();
    void DistanciaCorpo();
    double CalculoForca();
    double CalculoVelocidadeEscape();
    double CalculoVelocidadeOrbita();
    double CalculoCampo();
};

#endif // SISTEMA_INTERESTELAR_H_INCLUDED
