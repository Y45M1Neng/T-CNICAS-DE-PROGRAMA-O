#include <iostream>
#include "Sistema_Interestelar.h"
#include "cpparquivo.c"
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;

int main()
{
    Sistema_Interestelar sistema;

    sistema.DadosPlanetas();
    sistema.DistanciaCorpo();
    
//ATRIBUINDO VARIÁVEIS PARA OS CÁLCULOS A SEREM IMPRESSOS NA SAÍDA
    double f_gravitacional = sistema.CalculoForca();
    double v_escape = sistema.CalculoVelocidadeEscape();
    double v_orbtal = sistema.CalculoVelocidadeOrbita();
    double c_gravitacional = sistema.CalculoCampo();
//SAÍDA DOS CÁLCULOS
    
    cout << "A força gravitacional é: " << scientific << setprecision(2) << f_gravitacional << "N" << endl;
    cout << "O campo gravitacional do maior corpo celeste é: " << scientific << setprecision(2) << c_gravitacional << " m/s²" << endl;
    cout << "A velocidade de escape do maior corpo é: " << scientific << setprecision(2) << v_escape / 1000.0 << " km/s" << endl;
    cout << "A velocidade em órbita do menor corpo em relação ao maior é: " << scientific << setprecision(2) << v_orbtal / 1000.0 << " km/s" << endl;
    
    return 0;
}
