#include "Sistema_Interestelar.h"
#include <cmath>

void Sistema_Interestelar::DadosPlanetas(){
        cout << "Preencha os dados par os dois corpos celetes..." << endl;
        cout << "Corpo 1" << endl;
        cout << "Nome:" << endl;
        cin >> corpo_1.nome;
        cout << "Massa:" << endl;
        cin >> corpo_1.massa;
        cout << "Raio:" << endl;
        cin >> corpo_1.raioPlaneta;

        cout << "Preencha os dados par os dois corpos celetes..." << endl;
        cout << "Corpo 2" << endl;
        cout << "Nome:" << endl;
        cin >> corpo_2.nome;
        cout << "Massa:" << endl;
        cin >> corpo_2.massa;
        cout << "Raio:" << endl;
        cin >> corpo_2.raioPlaneta;
    }

    void Sistema_Interestelar::DistanciaCorpo() {
        cout << "Distância entre os corpos:" << endl;
        cin >> distancia;
    }    

    double Sistema_Interestelar::CalculoForca(){

        return (constante_gravitacional * corpo_1.massa * corpo_2.massa)/(distancia * distancia);

    }
    double Sistema_Interestelar::CalculoVelocidadeEscape(){
        double massa_maior = max(corpo_1.massa, corpo_2.massa);
        return sqrt((2* constante_gravitacional * massa_maior)/distancia);
    }
    double Sistema_Interestelar::CalculoVelocidadeOrbita(){
        double massa_menor = min(corpo_1.massa, corpo_2.massa);
        double massa_maior = max(corpo_1.massa, corpo_2.massa);
        return sqrt((constante_gravitacional * massa_maior)/distancia);
    }
    double Sistema_Interestelar::CalculoCampo(){
        double raio_maior = max(corpo_1.raioPlaneta, corpo_2.raioPlaneta);
        return constante_gravitacional * (corpo_1.massa/raio_maior);
    }
