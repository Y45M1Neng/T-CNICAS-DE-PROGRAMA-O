#include "VEICULO.h"
#include <iostream>
using namespace std;

//IMPLEMENTAÇÃO DO CONSTRUTOR
Veiculo::Veiculo(float preço_do_litro, float capacidade_maxima , float consumo , float quilometragem){
    this->preço_do_litro = preço_do_litro;
    this->capacidade_maxima = capacidade_maxima;
    this->consumo = consumo;
    this->quantidade_de_litros = capacidade_maxima * 0.1;
    this-> quilometragem = quilometragem;
    this-> total_de_gasto = 0;
}
//DESTRUTOR
Veiculo::~Veiculo(){
    cout << "Objeto destruído!" << endl;
}
//CHAMADA DA CLASSE COM SUAS DETERMINADAS FUNÇÕES
float Veiculo::getPreçodoLitro(){
    return preço_do_litro;
}
void Veiculo::setPreçodoLitro(float preço_do_litro){
    this->preço_do_litro = preço_do_litro;
}
float Veiculo::getCapacidadeMaxima(){
    return capacidade_maxima;
}
void Veiculo::setCapacidadeMaxima(float capacidade_maxima){
    this->capacidade_maxima = capacidade_maxima;
}
float Veiculo::getConsumo(){
    return consumo;
}
void Veiculo::setConsumo(float consumo){
    this->consumo = consumo;
}
float Veiculo::getQuantidadedeLitros(){
    return quantidade_de_litros;
}
void Veiculo::setQuantidadedeLitros(float quantidade_de_litros){
    this-> quantidade_de_litros = quantidade_de_litros;
}
float Veiculo::getQuilometragem(){
    return quilometragem;
}
void Veiculo::setQuilometragem(float quilometragem){
    this -> quilometragem = quilometragem;
}
float Veiculo::getTotaldeGasto(){
    return total_de_gasto;
}
void Veiculo::setTotaldeGasto(float total_de_gasto){
    this->total_de_gasto = total_de_gasto;
}
float Veiculo::Abastecimento(float litros_abastecidos){
    if (this->quantidade_de_litros + litros_abastecidos > capacidade_maxima){
        cout << "Abastecimento cancelado" << endl;
        return 0;
    }else{
        float valor_total1 = this->preço_do_litro * litros_abastecidos * 1.025;
        this -> quantidade_de_litros += litros_abastecidos;
        this->total_de_gasto += valor_total1;
        return valor_total1;
    }
}
float Veiculo::Autonomia(){
    return this-> consumo * this -> quantidade_de_litros;
}
bool Veiculo::PercorrerDistancia(float distancia){
    return distancia <= this->Autonomia();
}
void Veiculo::Deslocamento(float distancia){
    if(this->PercorrerDistancia(distancia)){
       this->quilometragem += distancia;
       float litros_consumidos = distancia/this->consumo;
       this->quantidade_de_litros -= litros_consumidos;
       cout << "Autonomia do veículo: " << this->quilometragem << "Km." << endl;
       cout << "Quantidade de litros no tanque até o destino: "<<this->quantidade_de_litros<< "litros" << endl;
    }else{
        cout << "Autonomia insuficiente." << endl;
    }
}
