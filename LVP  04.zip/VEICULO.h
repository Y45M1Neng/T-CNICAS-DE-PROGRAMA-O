#ifndef VEICULO_H_INCLUDED
#define VEICULO_H_INCLUDED

class Veiculo{
/*
Crie uma classe chamada Veículo para calcular valor de um serviço veicular. A classe deve armazenar atributos como: Preço do Litro, Capacidade Máxima em Litros do Tanque do Veículo, Consumo
em km/L, Quantidade de litros no tanque, Quilometragem do veículo e o Total gasto.
*/
private:
    float preço_do_litro;
    float capacidade_maxima;
    //float litros_do_tanque;
    float consumo;
    float quantidade_de_litros;
    float quilometragem;
    float total_de_gasto;
public:
    //Construtor  e destrutor
    Veiculo(float preço_do_litro = 0, float capacidade_maxima = 0, float consumo = 0, float quilometragem = 0);
    ~Veiculo();
    //FUNÇÕES PARA OS MÉTODOS NO ARQUIVO.CPP
    float getPreçodoLitro();
    void setPreçodoLitro(float preço_do_litro);
    float getCapacidadeMaxima();
    void setCapacidadeMaxima(float capacidade_maxima);
    float getConsumo();
    void setConsumo(float consumo);
    float getQuantidadedeLitros();
    void setQuantidadedeLitros(float quantidade_de_litros);
    float getQuilometragem();
    void setQuilometragem(float quilometragem);
    float getTotaldeGasto();
    void setTotaldeGasto(float total_de_gasto);
    //
    float Abastecimento(float litros_abastecidos);
    float Autonomia();
    bool PercorrerDistancia(float distancia);
    void Deslocamento(float distancia);
};


#endif // VEICULO_H_INCLUDED
