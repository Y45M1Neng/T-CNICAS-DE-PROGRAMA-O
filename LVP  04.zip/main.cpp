#include <iostream>
#include "VEICULO.h"
#include "cpparquivo.c"
#include <string>

using namespace std;

int main()
{
    float consumo;
    float capacida_maxima;
    float preço_do_litro;
    cout << "Insira o consumo  do veículo:" << endl;
    cin >> consumo;
    cout << "Insira a capacidade do veículo:"<<endl;
    cin >> capacida_maxima;
    cout << "Insira o preço do litro"<<endl;
    cin >> preço_do_litro;
    Veiculo veiculo(consumo, capacida_maxima, preço_do_litro);
    int opção=1;
    while (opção == 1){
        float litros_abastecidos, percuso;
        cout << "Insira a quantodade de litros que deseja colocar:" << endl;
        cin >> litros_abastecidos;
        cout << "Insira o percurso a ser feito:"<<endl;
        cin>> percuso;
        float valor_total = veiculo.Abastecimento(litros_abastecidos);
        cout << "Valor total da compra: " << valor_total << "R$" << endl;
        cout << "Autonomia do veículo: " << veiculo.Autonomia()<<"Km"<<endl;
        if (veiculo.PercorrerDistancia(percuso)){
            cout <<"O veículo pode percorrer a distância." << endl;
            veiculo.Deslocamento(percuso);
        }else{
            cout << "O veículo não pode percorrer a distância."<< endl;

        }
        cout << "1-Continuar | 2- Sair do programa" << endl;
        cin >> opção;
    }

    return 0;
}
