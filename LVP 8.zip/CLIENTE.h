#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED

#include "PESSOAA.h"

class Cliente : public Pessoa {
private:
    string produtos;
    double preco;

public:
    Cliente(string nome, string cpf, string telefone);
    string getProdutos();
    double getPreco();
    void escolherProduto(string produtos, double preco);
    void imprimir_os_dados();
};


#endif // CLIENTE_H_INCLUDED
