#include "CLIENTE.h"
#include <iostream>


Cliente::Cliente(string nome, string cpf, string telefone)
    : Pessoa(nome, cpf, telefone), produtos(""), preco(0.0) {}

string Cliente::getProdutos(){
    return produtos;
}
double Cliente::getPreco(){
    return preco;
}
void Cliente::escolherProduto(string produtos, double preco) {
    this-> produtos = produtos;
    this->preco = preco;
}
void Cliente::imprimir_os_dados(){
    Pessoa::imprimir_os_dados();
    cout <<"O Produto Escolhido eh: " << getProdutos()<<endl;
	cout<<"O preço eh: " << getPreco() << endl;
}
