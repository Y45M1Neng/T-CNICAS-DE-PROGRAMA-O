//Nome:Yasmin Santos Gonçalves

#include <iostream>
#include <locale>
#include <string>

using namespace std;

#include "FUNCIONARIO.cpp"
#include "CLIENTEE.cpp"
#include "PESSOA.cpp"


int main() {
    setlocale (LC_ALL, "Portuguese");
    string nome_do_funcionario, cpf_do_funcionario, telefone_do_funcionario, senha_do_funcionario;
    int num_identificacao_do_funcionario;
    float salario_do_funcionario;
    string nome_do_cliente, cpf_do_cliente, telefone_do_cliente;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    cout << "-------CADASTRO DE FUNCIONARIO-------" <<endl<<endl;
    cout << "Digite o nome do funcionario :"<<endl;
    cin>>nome_do_funcionario;
    cout << "Digite o CPF do funcionario : "<<endl;
    cin >> cpf_do_funcionario;
    cout << "Informe o Telefone do funcionario : "<<endl;
    cin >> telefone_do_funcionario;
    cout << "Digite o numero de identificacao do funcionario : "<<endl;
    cin >> num_identificacao_do_funcionario;
    cout << "Informe a senha do funcionario : "<<endl;
    cin >> senha_do_funcionario;
    cout << "Informe o salario do funcionario "<<endl;
    cin >> salario_do_funcionario;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    Funcionario funcionario(nome_do_funcionario, cpf_do_funcionario, telefone_do_funcionario, num_identificacao_do_funcionario, senha_do_funcionario, salario_do_funcionario);

    cout << "-------CADASTRO DE FUNCIONARIO-------" <<endl<<endl;
    cout << "Digite o nome do cliente "<<endl;
    cin>>nome_do_cliente;
    cout << "Digite o cpf do cliente: "<<endl;
    cin >> cpf_do_cliente;
    cout << "Informe o telefone do cliente : "<<endl;
    cin >> telefone_do_cliente;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    Cliente cliente(nome_do_cliente, cpf_do_cliente, telefone_do_cliente);
    string teste;
    cout<< "--PARA VERIFICAR O TIPO DE USUARIO SEGUE A SEGUINTE INSTRUCAO-- "<<endl<<endl;
    cout<<"Digite(funcionario) ou Digite(cliente):"<<endl;
    cin >> teste;

    if (teste =="funcionario") {
        string senha;
        cout << "Por gentileza, informe a sua senha: ";
        cin >> senha;

        if (funcionario.verificar_a_Senha(senha)) {
            cout << "Ola, sua senha foi conferida com sucesso, voce tem acesso ao sistema "<<endl;
            funcionario.imprimir_os_dados();
        } else {
            cout << "ERRO, sua senha nao é valida  "<<endl;
        }
    } else if (teste == "cliente") {
        string produto;
        double preco;

        cout <<"Escolha um dos produtos, Opcoes abaixos:"<<endl;
		cout<<"(1.opcao)- celular 900R$:"<<endl;
		cout<<"(2.opcao)- multimetro 200R$:"<<endl;
		cout<<"(3.opcao)-computador 2000R$:"<<endl;
		cout<<"informe qual opcao voce escolheu:"<<endl;
        cin >> produto;
        cout <<"Informe o preco do produto escolhido:"<<endl;
        cin >> preco;
        cliente.escolherProduto(produto, preco);
        cout << "--OS DADOS SAO--"<<endl;
        cliente.imprimir_os_dados();
    } else {
        cout << "ERRO,opcao nao valida"<<endl;
    }

    return 0;
}

