#ifndef PESSOAA_H_INCLUDED
#define PESSOAA_H_INCLUDED
class Pessoa {

private:
    string nome;
    string cpf;
    string telefone;

public:
      Pessoa(string nome, string cpf, string telefone);
      string getNome();
   	  string getCPF();
      string getTelefone();
      void imprimir_os_dados();

};



#endif // PESSOAA_H_INCLUDED
