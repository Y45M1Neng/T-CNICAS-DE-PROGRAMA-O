#include "FUNCIONARIO.h"

Funcionario::Funcionario(string nome, string cpf, string telefone,
                        int num_de_identificacao, string senha, float salario)
    : Pessoa(nome, cpf, telefone), num_de_identificacao(num_de_identificacao), senha(senha), salario(salario) {}

int Funcionario::getNumidentificacao(){
    return num_de_identificacao;
}
string Funcionario::getSenha() {
    return senha;
}
float Funcionario::getSalario(){
    return salario;
}
void Funcionario::imprimir_os_dados(){
    Pessoa::imprimir_os_dados();
    cout <<"O numero de identificacao eh: " << getNumidentificacao() << endl;
	cout<< "O salario eh " << getSalario() << endl;
}
bool Funcionario::verificar_a_Senha( string senha_informada) {
    return getSenha() == senha_informada;
}
