#include "PESSOAA.h"


Pessoa::Pessoa(string nome, string cpf, string telefone)
    : nome(nome), cpf(cpf), telefone(telefone) {}

string Pessoa::getNome(){
    return nome;
}
string Pessoa::getCPF(){
    return cpf;
}
string Pessoa::getTelefone(){
    return telefone;
}
void Pessoa::imprimir_os_dados(){

    cout << "O nome eh : " << getNome()<<endl;
    cout<<"O CPF eh: " << getCPF() <<endl;
	cout<<"O Telefone: " << getTelefone() << endl;
}
