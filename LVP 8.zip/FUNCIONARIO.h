#ifndef FUNCIONARIO_H_INCLUDED
#define FUNCIONARIO_H_INCLUDED

#include "PESSOAA.h"

class Funcionario : public Pessoa {
private:
    int num_de_identificacao;
    string senha;
    float salario;

public:
    Funcionario( string nome, string cpf, string telefone,
                int num_de_identificacao, string senha, float salario);

    int getNumidentificacao();
    string getSenha();
    float getSalario();
    void imprimir_os_dados();
    bool verificar_a_Senha(string senha_informada);
};


#endif // FUNCIONARIO_H_INCLUDED
