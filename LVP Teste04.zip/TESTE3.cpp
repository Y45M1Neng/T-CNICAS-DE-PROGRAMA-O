#include <iostream>

using namespace std;

int calculo_segundos(int h, int m, int s){
    int total_segundos = ((h*3600) + (m*60) + (s));
    return total_segundos;
}
int main(){
    int h, m, s;

    cout << "Insira o numero de horas: "; cin >> h;
    cout << "Insira o numero de minutos: "; cin >> m;
    cout << "Insira o numero de segundos: "; cin >> s;
    int total_segundos = (calculo_segundos(h, m,s));
    cout << "O total de segundos é: " << total_segundos << endl;

    return 0;
}
