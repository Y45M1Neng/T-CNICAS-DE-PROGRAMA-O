#include "TaxaRendimento.h"


void TaxaRendimento::setNome(string nome){
	this->nome=nome;
}
string TaxaRendimento::getNome(){
	return nome;
}
void TaxaRendimento::setSaldo(float saldo){
	this->saldo=saldo;
}
float TaxaRendimento::getSaldo(){
	return saldo;
}
float TaxaRendimento::calculeValor_rendimento()  const{
	return (saldo*((TaxaSelic/100))/12)+(saldo-(saldo*(0.3/100)));
}
 void TaxaRendimento::modifiqueTaxaSelic(float valor_novo){
	TaxaSelic = valor_novo;
} 

float TaxaRendimento::getTaxaSelic(){
	return TaxaSelic;
}
float TaxaRendimento::TaxaSelic = 13.75;