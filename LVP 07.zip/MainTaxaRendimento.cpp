// Nome: Yasmin Santos Gonçalves
// Matricula: 123111117
//Disciplina:
//LVP 07
// Professor:


#include <iostream>
#include <locale>
#include <iomanip>
#include <stdlib.h>

using namespace std;
#include "TaxaRendimento.cpp"

int main(){

	string nome1,nome2;
	float saldo1, saldo2;
    TaxaRendimento num1;
    TaxaRendimento num2;
	cout<<"Informe o nome da primeira pessoa: " <<endl;
	cin>> nome1;
    cout<<"Informe o nome da segunda pessoa: " <<endl;
	cin>> nome2;
	cin.ignore();
	cout<<"Informe o Deposito da 1 pessoa: "<< endl;
	cin>>saldo1;
	cout<<"Informe o Deposito da 2 pessoa: "<< endl;
	cin>>saldo2;
    num1.setNome(nome1);
    num2.setNome(nome2);
	num1.setSaldo(saldo1);
	num2.setSaldo(saldo2);
	cout<<" Primeiro mes de aplicacao: "<<endl;
	cout<<"O rendimento do poupador 1 eh (se for TesouroDireto)eh:"<<num1.calculeValor_rendimento()<<endl;
	cout<< "O rendimento do poupador 2 eh (se for TesouroDireto)eh: "<<num2.calculeValor_rendimento()<<endl;
///////////////////////////////////////////////////////////////
    float rendimento1=num1.calculeValor_rendimento();
    float rendimento2=num2.calculeValor_rendimento();
	TaxaRendimento::modifiqueTaxaSelic(13.25);
	num1.setSaldo(rendimento1);
	num2.setSaldo(rendimento2);
	cout<<endl<<endl;
	system("pause");
	cout<<"Segundo mes de aplicacao: "<<endl;
	cout<<"O rendimento do poupador 1 eh (se for TesouroDireto)eh:"<<num1.calculeValor_rendimento()<<endl;
	cout<<"O rendimento do poupador 2 eh (se for TesouroDireto)eh: "<<num2.calculeValor_rendimento()<<endl;
/////////////////////////////////////////////////////////////////////////

  return 0;

}
