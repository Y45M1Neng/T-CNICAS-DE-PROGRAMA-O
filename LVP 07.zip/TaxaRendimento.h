#ifndef TAXARENDIMENTO_H
#define TAXARENDIMENTO_H
using namespace std;
class TaxaRendimento{
    static float TaxaSelic ;
	private:
        float saldo;
		string nome;
	public :
	    void setNome(string nome);
	    string getNome();
	    void setSaldo(float saldo);
	    float getSaldo();
        float calculeValor_rendimento() const;
        static void modifiqueTaxaSelic(float);
        static float getTaxaSelic();
};
#endif
