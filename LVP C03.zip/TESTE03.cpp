#include <iostream>
using namespace std;

int inverte_digitos(int numero);

int main(){
	
	int numero;
	cout << "Informe um inteiro positivo para ser invertido: ";
	cin >> numero;
	inverte_digitos(numero);
	return 0;
}
int inverte_digitos(int numero){
	
	if ( numero >= 0){
	    cout << "Numero invertido: ";
	} 
	else {
	    cout << "Numero invertido: -";
	    numero *= -1;
	    }
	do {
			int cifra = numero % 10;
			cout << cifra;
			numero /= 10; 
		
		} while(numero != 0);
	cout<< endl;
	return 0;	
	}
	

	