#include <iostream>
#include <iomanip>
using namespace std;

int main(){
    float primeiro_numero, segundo_numero; //variáveis
    double soma, subtracao, multiplicacao, divisao; 
    char operador;
    cout << "Informe o primero operando: ";  //entradas
    cin >> primeiro_numero;
    cout << "Informe o segundo operando: "; 
    cin >> segundo_numero;
    cout << "Informe o operador (+, -, * ou /): "; 
    cin >> operador;
    //usei o case para a cada escolha "uma condição" a ser feita
    switch(operador)
    {
        case '+':
            soma = primeiro_numero + segundo_numero;
            cout << fixed << setprecision(1);
            cout << "Resultado da adição: " << soma << endl;
            break;
        case '-':
            subtracao = primeiro_numero - segundo_numero;
            cout << "Resultado da subtração: " << subtracao << endl;
            break;
        case '*':
            multiplicacao = primeiro_numero * segundo_numero;
            cout << "Resultado da multiplicação: " << multiplicacao << endl;
            break;
        case '/':
            if (segundo_numero != 0){
                divisao = (primeiro_numero) / segundo_numero;
                cout << fixed << setprecision(15);
                cout << "Resultado da divisão: " << divisao << endl;
            } else{
                cout << "Divisao por zero inválida!" << endl; 
            }
            break;
        default:
            cout << "Operador inválido!" << endl; //caso adicione uma coisa diferente do esperado, o programa para e imprime essa mensagem
    }
    return 0;
}