#include "Paciente.h"

Paciente::Paciente(){
	
	nome_paciente=" ";
	cpf_paciente= " ";
	motivo_do_atendimento=" ";
	n_lista=0;
}

void Paciente::setNomePaciente(string nome){
	nome_paciente=nome;
}

void Paciente::setCpfPaciente(string cpf){
	cpf_paciente=cpf;
}
void Paciente::setMotivoDoAtendimento(string motivo){
	motivo_do_atendimento=motivo;
}
void Paciente::setNLista(int numero_lista){
	n_lista=numero_lista;
}

string Paciente::getNomePaciente(){
	return nome_paciente;
}
string Paciente::getCpfPaciente(){
	return cpf_paciente;
}
string Paciente::getMotivoDoAtendimento(){
	return motivo_do_atendimento;
}
int Paciente::getNLista(){
	return n_lista;
}

void Paciente::exibir_dados(){
	cout<<"Nome do paciente: "<<nome_paciente<<endl;
	cout<<"CPF do paciente: "<<cpf_paciente<<endl;
	cout<<"motivo do atendimento: "<<motivo_do_atendimento<<endl;
}