#ifndef HOSPITAL_H
#define HOSPITAL_H

class Hospital{
	vector <Paciente> lista_de_espera;
	vector <Paciente> lista_de_atendidos;
	
	public:
		void AdicionarPaciente(Paciente);
		void AtenderPaciente();
		void BuscarPaciente();
		void ExibierPacientesAtendidos();
};
#endif
