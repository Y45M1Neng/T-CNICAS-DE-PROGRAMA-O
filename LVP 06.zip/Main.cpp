#include <iostream>
#include <vector>
#include <locale>
#include <string>
#include <algorithm>

using namespace std;

#include "Paciente.cpp"
#include "Hospital.cpp"

int main(){
	setlocale(LC_ALL, "Portuguese");

	Paciente pessoa;
	Hospital universitario;

	string nome_paciente;
	string cpf_paciente;
	string motivo_do_atendimento;
	int n_lista;

	int alternativa;
	do{
	cout<<endl;
	cout<<"------Sistema de controle de sala de espera - Hospital universitário------"<<endl;
	cout<<"1- Adicionar Paciente"<<endl;
	cout<<"2- Atender paciente"<<endl;
	cout<<"3- Buscar paciente na lista de espera"<<endl;
	cout<<"4- Exibir pacientes já atendidos"<<endl;
	cout<<"5- Fechar programa"<<endl;
	cout<<"Digite uma opção: ";
	cin>>alternativa;

	if (alternativa==1){

			cout<<"Informe o nome do paciente: "<<endl;
			cin.ignore();
			getline(cin, nome_paciente);
			cout<<"Informe o CPF do paciente: "<<endl;
			cin>>cpf_paciente;
			cout<<"Informe o motivo do atendimento: "<<endl;
			cin.ignore();
			getline(cin, motivo_do_atendimento);
			cout<<"Informe o número do atendimento: "<<endl;
			cin>>n_lista;
			cout<<endl;

			pessoa.setNomePaciente(nome_paciente);
			pessoa.setCpfPaciente(cpf_paciente);
			pessoa.setMotivoDoAtendimento(motivo_do_atendimento);
			pessoa.setNLista(n_lista);

			universitario.AdicionarPaciente(pessoa);
		}else if(alternativa==2){
			universitario.AtenderPaciente();
		}else if(alternativa==3){
			universitario.BuscarPaciente();
		}else if (alternativa==4){
			universitario.ExibierPacientesAtendidos();
		}
	}while(alternativa<5);


}
