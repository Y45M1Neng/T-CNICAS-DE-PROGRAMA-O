#ifndef PACIENTE_H
#define PACIENTE_H

class Paciente{
	
	string nome_paciente;
	string cpf_paciente;
	string motivo_do_atendimento;
	int n_lista;
	
	public:
		Paciente();
		void setNomePaciente(string);
		void setCpfPaciente(string);
		void setMotivoDoAtendimento(string);
		void setNLista(int);
		string getNomePaciente();
		string getCpfPaciente();
		string getMotivoDoAtendimento();
		int getNLista();
		
		void exibir_dados();
};
#endif