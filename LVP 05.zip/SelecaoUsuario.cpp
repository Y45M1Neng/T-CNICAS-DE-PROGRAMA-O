#include "SelecaoUsuario.h"
#include <iostream>
using namespace std;

SelecaoUsuario::SelecaoUsuario(const string& cpf_do_usuario, const string& nome_do_usuario, int idade_do_usuario)
    : nome_do_usuario(nome_do_usuario), cpf_do_usuario(cpf_do_usuario), idade_do_usuario(idade_do_usuario), pontuacao(0) {}
bool SelecaoUsuario::VerificacaoAprovado() const {
    return (pontuacao == 100 && idade_do_usuario >= 22);
}
void SelecaoUsuario::ImpressaoContrato(const string& contratante, double salario) const {
    cout << "########################### CONTRATO ADMISSIONAL ##########################" << endl;
    cout << "Nome: " << nome_do_usuario << "     CPF: " << cpf_do_usuario << endl;
    cout << "Idade: " << idade_do_usuario << endl;
    cout << "Salário: R$" << salario << " + bonificações" << endl;
    cout << "Contratante: " << contratante << endl;
}

void SelecaoUsuario::VerificacaoResposta(int n_pergunta, int solucao) {
    int gabarito[] = {1, 2, 2, 1};
    if (solucao == gabarito[n_pergunta - 1]) {
        pontuacao += 25;
    }
}

int SelecaoUsuario::getRetornaPontos() const {
    return pontuacao;
}
