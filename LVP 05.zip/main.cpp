#include <iostream>
#include "SelecaoUsuario.h"
#include "SelecaoUsuario.cpp"
#include <string>

using namespace std;

int main()
{
   //int idade_do_usuario;
   //int salario = 2000;

    string cpf_do_usuario, nome_do_usuario, contratante;
    int idade_do_usuario;
    //int salario = 2000;

    cout << "##### Bem-vindo a Seleção de funcionários da empresa TP! ######"<<endl;
    //ENTRADA DE DADOS
    cout << "Vamos começar com o seu cadastro no nosso banco de dados:" << endl;
    cout << "Insira o seu nome: ";
    cin >> contratante;
    cout << "Insira o nome do usuário a ser cadastrado: ";
    cin >> nome_do_usuario;
    cout << "Insira sua idade: ";
    cin >> idade_do_usuario;
    cout << "Insira o CPF: ";
    cin >> cpf_do_usuario;
    cin.ignore();

    SelecaoUsuario usuario(cpf_do_usuario, nome_do_usuario, idade_do_usuario);
    int solucao;
    //
    cout << "Digite o número 1 para verdadeiro e 2 para falso:" << endl;
    cout << "A estrutura Union pode atribuir e armazenar mais de um valor a um atributo por execução: ";
    cin >> solucao;
    usuario.VerificacaoResposta(1, solucao);
    //
    cout << "Ao determinarmos o comando 'cout<<fixed<<setprecision(2)<<endl' estamos arredondando um valor de float para inteiro: ";
    cin >> solucao;
    usuario.VerificacaoResposta(2, solucao);
    //
    cout << "Usando a biblioteca ctime podemos gerar um número aleatório a partir da função srand(time(0)): ";
    cin >> solucao;
    usuario.VerificacaoResposta(3, solucao);
    //
    cout << "Podemos utilizar estruturas como classes, struct e union em programação orientada a objeto: ";
    cin >> solucao;
    usuario.VerificacaoResposta(4, solucao);
    //
    if (usuario.VerificacaoAprovado()){
        cout << "Parabéns, você foi selecionado!";
        cout << "Sua pontuação: " << usuario.getRetornaPontos() << "/100"<<endl;
        usuario.ImpressaoContrato("Nome do Contratante", 2000.00); // Chamando a função ImpressaoContrato
    }else{
        cout << "Você não é o padrão que nossa empresa procura, até logo!" << endl;
        cout << "Obrigado por nos dar uma chance de entrevistá-lo" << endl;
    }
    //cout << "Sua pontuação: " << usuario.getRetornaPontos() << "/100"<<endl;
    //cout << "########################### CONTRATO ADMISSIONAL ##########################" << endl;
    //cout << "Nome: " << nome_do_usuario << "     CPF:" << cpf_do_usuario << endl;
    //cout << "Salário: R$" << salario << " + bonificações" << endl;
    //cout << "Contratante: " << contratante << endl;
    cout <<"##############################################################################";
    return 0;
}

