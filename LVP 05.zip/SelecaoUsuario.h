#ifndef SELECAOUSUARIO_H_INCLUDED
#define SELECAOUSUARIO_H_INCLUDED

//PROFESSOR, NO CODEBLOCK RODA E AQUI NÃO! :(
#include <string>
using namespace std;

class SelecaoUsuario{
private:
    int idade_do_usuario, pontuacao;
    string nome_do_usuario, cpf_do_usuario;
public:
//METODOS DA ORDEM DA PERGUNTA
    SelecaoUsuario(const string& cpf_do_usuario, const string& nome_do_usuario, int idade_do_usuario);
    bool VerificacaoAprovado() const;
    void ImpressaoContrato(const string& contratante, double salario) const;
    void VerificacaoResposta(int n_pergunta, int solucao);
    int getRetornaPontos() const;
};


#endif // SELECAOUSUARIO_H_INCLUDED
