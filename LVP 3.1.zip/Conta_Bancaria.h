#ifndef CONTA_BANCARIA_H_INCLUDED
#define CONTA_BANCARIA_H_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class ContaBancaria {
private:
    string nome_do_titular;
    string numero_da_conta;
    string senha_da_conta;
    double saldo;

public:
    ContaBancaria();
    void setNomedoTitular(const string nome);
    void setNumerodaConta(const string numero);
    bool verificacaoSenha(const string senha_digitada) const;
    void deposito(double valor);
    void saque(double valor, const string senha_digitada);
    double getsaldo() const;
};

#endif // CONTA_BANCARIA_H_INCLUDED