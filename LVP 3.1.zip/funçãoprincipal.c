#include <iostream>
#include "Conta_Bancaria.h"
#include "cpparquivo.cpp"
#include <string>
using namespace std;

int main() {
    //ATRIBUINDO AS CONTAS NA CLASSE
    ContaBancaria conta1;
    ContaBancaria conta2;
    //ATRIBUINDO VARIÁVEIS PARA OS DADOS DE ENTRADA
    string nome_do_titular1, senha1, nome_do_titular2, senha2;
    double saldo_inicial1 = 20.00, saldo_inicial2 = 30.00, saque1, deposito1, saque2, deposito2;

    cout << "Bem vindo ao Banco TP" << endl;
    //CLIENTE 1
    cout << "Qual o seu nome?" << endl;
    getline(cin, nome_do_titular1);
    conta1.setNomedoTitular(nome_do_titular1);

    cout << "Digite uma senha:" << endl;
    getline(cin, senha1);
    conta1.setSenha(senha1);

    cout << "O número da sua conta é 001" << endl;
    //CLIENTE 2
    cout << "Qual o seu nome?" << endl;
    getline(cin, nome_do_titular2);
    conta2.setNomedoTitular(nome_do_titular2);

    cout << "Digite uma senha:" << endl;
    getline(cin, senha2);
    conta2.setSenha(senha2);

    cout << "O número da sua conta é 002" << endl;
    //SALDOS
    cout << "Saldo de " << nome_do_titular1 << " - R$" << saldo_inicial1 << endl;
    cout << "Saldo de " << nome_do_titular2 << " - R$" << saldo_inicial2 << endl;
    //PARA CALCULAR QUANDO DIGITAR O VALOR QUE QUER SACAR
    cout << "Qual o valor do saque?" << endl;
    cin >> saque1;
    cout << "Digite a senha:" << endl;
    cin.ignore();
    getline(cin, senha1);
    conta1.saque(saque1, senha1);
    //PARA CALCULAR O VALOR DO DEPÓSITO DEPOIS QUE ELE ADICIONAR NA CONTA
    cout << "Qual o valor do depósito?" << endl;
    cin >> deposito1;
    conta1.deposito(deposito1);

    cout << "Qual o valor do saque?" << endl;
    cin >> saque2;
    cout << "Digite a senha:" << endl;
    cin.ignore();
    getline(cin, senha2);
    conta2.saque(saque2, senha2);

    cout << "Qual o valor do depósito?" << endl;
    cin >> deposito2;
    conta2.deposito(deposito2);

    cout << "Saldo da conta " << nome_do_titular1 << " - R$ " << conta1.getsaldo() << endl;
    cout << "Saldo da conta " << nome_do_titular2 << " - R$ " << conta2.getsaldo() << endl;

    return 0;
}
