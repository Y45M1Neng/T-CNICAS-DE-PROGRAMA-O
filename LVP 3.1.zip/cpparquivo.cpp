#include "Conta_Bancaria.h"

//ARQUIVO.CPP TENDO AS FUNÇÕES PRINCIPAIS.
/*/ void deposito(double valor); //FUNÇÃO DEPOSITO
    void saque(double valor, const string senhaPessoa);//'' SAQUE
    double getsaldo()const; //EXIBIR VALOR
    bool verificaraçãoSenha( const string senhaPessoa) const; //USANDO CONST PARA A FUNÇÃO NÃO MODIFICAR O CONTEÚDO DA STRING E O ESTADO DO OBJETO.
    void setSenha(const string newSenha);
    void setNomedoTitular(const string nome);
    void setNumerodaConta(const string numero)/*/

ContaBancaria::ContaBancaria() {
    saldo = 0;
}

void ContaBancaria::setNomedoTitular(const string nome) {
    nome_do_titular = nome;
}

void ContaBancaria::setNumerodaConta(const string numero) {
    numero_da_conta = numero;
}

bool ContaBancaria::verificacaoSenha(const string senha_digitada) const {
    return senha_da_conta == senha_digitada;
}

void ContaBancaria::deposito(double valor) {
    saldo += valor;
    cout << "Depósito de R$" << valor << " realizado com sucesso." << endl;
}

void ContaBancaria::saque(double valor, const string senha_digitada) {
    if (verificacaoSenha(senha_digitada)) {
        if (saldo - valor >= 0) {
            saldo -= valor;
            cout << "Saque de R$" << valor << " realizado com sucesso." << endl;
        } else {
            cout << "Saldo insuficiente." << endl;
        }
    } else {
        cout << "Senha incorreta." << endl;
    }
}

double ContaBancaria::getsaldo() const {
    return saldo;
}