#include <iostream>
#include <vector>
using namespace std;

int main(){
    // vairáveis
    float  nota, soma = 0, resultado;
   
    vector <float> notas; // vetor com a variável float
    
	cout << "Informe as notas dos alunos (valor negativo para parar): "<< endl;
    
    while(true){ //se a condição de ter inserido um valor negativo, vai parar as listagens das notas e armazenar.
        cin >> nota;
        if (nota < 0 ){
            break;
        }
        notas.push_back(nota); // retorna uma referência para o último elemento no vetor. o vetor está preenchido com as notas.
    }
  
    for ( float y : notas) {
        soma += y;
    }
    resultado = soma/notas.size(); //retorna o números de notas do vetor.
    cout << "Média = " << resultado << endl; //vai imprimir o valor.
    
   
    
    for ( float y : notas){// "y" representa cada elemento do vetor nota
        if (y < resultado){
            cout << y << endl; 
        }
    }    
    return 0;
}    
