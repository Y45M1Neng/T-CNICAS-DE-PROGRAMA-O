#include <iostream>

using namespace std;

int main(){
    int a, b, resto;
    cout << "Digite o primeiro valor: " << endl;
    cin >> a;
    cout << "Digite o segundo valor: " << endl;
    cin >> b;
    resto = a % b;
    cout << "Resultado = " << resto << endl;
    return 0;
}
