#include <iostream>
#include <iomanip>

using namespace std;

int main(){
    int numero_dl;
    cout << "Insira o numero de lados: " << endl;
    cin >> numero_dl;
    double numero_dd = numero_dl*(numero_dl - 3)/2;
    cout << fixed << setprecision(1);
    cout << "A quantidade de diagonais diferentes que o polígono possui: " << numero_dd << endl;
    return 0;
}
