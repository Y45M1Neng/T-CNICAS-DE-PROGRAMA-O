#include "Hospital.h"

void Hospital::AdicionarPaciente(Paciente paciente){
	lista_de_espera.push_back(paciente);
	cout<<"paciente adicionado a lista de espera com sucesso!"<<endl;
}
void Hospital::AtenderPaciente(){
	if (!lista_de_espera.empty()){
		lista_de_atendidos.push_back(lista_de_espera[0]);
		cout<<"paciente atendido"<<endl;
		lista_de_espera.erase(lista_de_espera.begin());
	}else{
		cout<<"lista de espera vazia"<<endl;
	}
}
void Hospital::BuscarPaciente(){
	int NumeroDoAtendimento;
	cout<<"informe o numero de atendimento: "<<endl;
	cin>>NumeroDoAtendimento;
	
	bool PacienteEncontrado = false;
	
	for (unsigned indice(0); indice<lista_de_espera.size(); indice++){
		
		if (NumeroDoAtendimento == lista_de_espera[indice].getNLista()){
			
			cout<<"nome do paciente: "<<lista_de_espera[indice].getNomePaciente()<<endl;
			cout<<"CPF: "<<lista_de_espera[indice].getCpfPaciente()<<endl;
			cout<<"motivo do atendimento: "<<lista_de_espera[indice].getMotivoDoAtendimento();
			
			PacienteEncontrado = true;
		}
	}if(!PacienteEncontrado){
		cout<<"Paciente não encontrado na lista de espera.";
	}	
}
bool ordenaPorNumero(Paciente A, Paciente B){
	if (A.getNLista()<B.getNLista()){
		return true;
    }return false;
}
void Hospital::ExibierPacientesAtendidos(){
	system("cls");
	if (!lista_de_atendidos.empty()){
		vector<Paciente> p(lista_de_atendidos.size());
		copy(lista_de_atendidos.begin(), lista_de_atendidos.end(), p.begin());
		sort(p.begin(), p.end(), ordenaPorNumero);
		cout<<"lista de pacientes ja atendidos: "<<endl;
		for (unsigned indice(0); indice<p.size(); indice++){
			cout<<indice+1<<" Paciente "<<endl;
			p[indice].exibir_dados();
			cout<<endl;
		}}
	else{
		cout<<"não há pacientes ";
	}
}